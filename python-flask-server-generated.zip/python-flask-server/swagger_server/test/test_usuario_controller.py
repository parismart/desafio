# coding: utf-8

from __future__ import absolute_import

from flask import json
from six import BytesIO

from swagger_server.test import BaseTestCase


class TestUsuarioController(BaseTestCase):
    """UsuarioController integration test stubs"""

    def test_upload_file(self):
        """Test case for upload_file

        Crea un usuario y te devuelve el ID
        """
        query_string = [('age', 789),
                        ('gender', 'gender_example'),
                        ('time', 789),
                        ('route_type', 'route_type_example'),
                        ('price', 'price_example'),
                        ('difficulty', 'difficulty_example'),
                        ('companions', 'companions_example'),
                        ('transport', 'transport_example')]
        response = self.client.open(
            '//postUser',
            method='POST',
            content_type='multipart/form-data',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    import unittest
    unittest.main()
