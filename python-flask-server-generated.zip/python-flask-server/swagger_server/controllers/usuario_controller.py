import connexion
import six

from swagger_server import util


def upload_file(age, gender, time, route_type, price, difficulty, companions, transport):  # noqa: E501
    """Crea un usuario y te devuelve el ID

     # noqa: E501

    :param age: Año de nacimiento del usuario
    :type age: int
    :param gender: Género del usuario.(Hombre, Mujer, Otro)
    :type gender: str
    :param time: Minutos de ruta
    :type time: int
    :param route_type: Tipo de ruta
    :type route_type: str
    :param price: Precio de la ruta dispuesto a pagar
    :type price: str
    :param difficulty: Dificultad de la ruta
    :type difficulty: str
    :param companions: Con quién vas a ir
    :type companions: str
    :param transport: Transporte para la ruta
    :type transport: str

    :rtype: None
    """
    return 'do some magic!'
