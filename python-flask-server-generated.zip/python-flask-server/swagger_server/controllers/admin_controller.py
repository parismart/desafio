import connexion
import six

from swagger_server import util


def find_pets_by_tags(Id):  # noqa: E501
    """Encuentra rutas por ID

     # noqa: E501

    :param Id: ID to filter by
    :type Id: int

    :rtype: None
    """
    return 'do some magic!'


def get_poi_by_id(Id):  # noqa: E501
    """Encuentra un POI por su ID

     # noqa: E501

    :param Id: ID of pet to return
    :type Id: int

    :rtype: None
    """
    return 'do some magic!'


def get_recommendation(userId):  # noqa: E501
    """Usa los datos de un usuario y predice la mejor ruta según su perfil

     # noqa: E501

    :param userId: Id del usuario a recomendar
    :type userId: int

    :rtype: None
    """
    return 'do some magic!'


def receive_poi():  # noqa: E501
    """Recibe un JSON de todos los puntos de interés

     # noqa: E501


    :rtype: None
    """
    return 'do some magic!'


def receive_route():  # noqa: E501
    """Recibe un JSON de todas las rutas

     # noqa: E501


    :rtype: None
    """
    return 'do some magic!'
